package com.carpool.dao;

import java.sql.SQLException;

import com.carpool.model.UserModel;

public interface UserDaoInterface 
{
	public void addUser(UserModel user) throws SQLException;
	public UserModel getEmailID(String email) throws SQLException;
	public boolean updateUser(UserModel um) throws SQLException;
	

}
