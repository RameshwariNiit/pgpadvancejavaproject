package com.carpool.dao;


import java.sql.*;

import com.carpool.DBCONFIG.DatabaseConfig;
import com.carpool.model.LoginModel;

public class AuthenticateUser
{
	
	public String authenticateUser(LoginModel lbean)
	{
		String emailid = lbean.getEmailid();
		String password = lbean.getPassword();
		
		DatabaseConfig db = new DatabaseConfig();
		
		Connection con = null;
		Statement smt = null;
		ResultSet rs = null;
		
		String email="";
		String pass="";
		
			System.out.println(email+pass);
		
		try
		{
			con = db.createConnection();
			smt = con.createStatement();
			rs = smt.executeQuery("select emailid , password  from RegisterTable where emailid ='"+emailid+"' and password ='"+password+"'");
			
			while(rs.next())
			{
				email= rs.getString("emailid");
				pass= rs.getString("password");
				
				if((emailid.equals(email)) && (password.equals(pass)))
				{
					return "Success";
					
				}
					
			}
				
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		
		return "Invalid user Credintials";
	}

}
