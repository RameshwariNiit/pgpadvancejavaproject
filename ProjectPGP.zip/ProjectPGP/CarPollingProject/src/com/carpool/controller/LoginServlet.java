package com.carpool.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.carpool.dao.AuthenticateUser;
import com.carpool.model.LoginModel;

@SuppressWarnings("serial")
@WebServlet("/login")
public class LoginServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String email = request.getParameter("email");
		 String password = request.getParameter("password");
		 
		 LoginModel lm = new LoginModel();
		 lm.setEmailid(email);
		 lm.setPassword(password);
		 
		 AuthenticateUser auser = new AuthenticateUser();
		 String userValidate = auser.authenticateUser(lm);
		 ;
		 System.err.println(userValidate);
		 
		 if(userValidate.equalsIgnoreCase("success"))
		 {
			 HttpSession httpSession=request.getSession();
			 
			 httpSession.setAttribute("EmailID", email);

			 response.sendRedirect("UserPage.jsp");
		 }
		 else
		 {
			 request.setAttribute("ErrorMsg", userValidate);
			 request.getRequestDispatcher("/LoginPage.jsp").include(request, response);
		 }

	}
	
	public void doPost(HttpServletRequest request , HttpServletResponse response ) throws ServletException, IOException
	{
		doGet(request, response);
	}
}
