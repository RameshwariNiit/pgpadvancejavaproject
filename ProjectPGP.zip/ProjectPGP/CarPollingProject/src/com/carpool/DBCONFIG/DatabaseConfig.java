package com.carpool.DBCONFIG;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConfig implements DBConnection
{

	public Connection createConnection() 
	{

		Connection con=null;
		
		String url ="jdbc:h2:tcp://localhost/~/myproject";
		String username="sa";
		String password="sa@123";
		
		try
		{
			try{
			
				Class.forName("org.h2.Driver");
				System.out.println("Driver Loaded ...");
			}
			catch(ClassNotFoundException ce)
			{
				ce.printStackTrace();
			}
		
			
			con = DriverManager.getConnection(url,username,password);
			System.out.println("Connection  established"+con);
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
			return con;
		
	}
	


	
}
