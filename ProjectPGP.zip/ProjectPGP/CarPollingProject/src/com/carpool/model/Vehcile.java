package com.carpool.model;

public class Vehcile {

	private int vehicleId;
	private VechileType vechileType;
	private String vechileNumber;
	private int noOfSeating;
	private float pricePerKm;

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public VechileType getVechileType() {
		return vechileType;
	}

	public void setVechileType(VechileType vechileType) {
		this.vechileType = vechileType;
	}

	public int getNoOfSeating() {
		return noOfSeating;
	}

	public void setNoOfSeating(int noOfSeating) {
		this.noOfSeating = noOfSeating;
	}

	public float getPricePerKm() {
		return pricePerKm;
	}

	public void setPricePerKm(float pricePerKm) {
		this.pricePerKm = pricePerKm;
	}

}
