package com.carpool.model;

public enum VechileType {
	MICRO,MINI,PRIME

}
