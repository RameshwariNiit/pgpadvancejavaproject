package com.carpool.model;

public enum UserType 
{
	Customer, Admin

}
